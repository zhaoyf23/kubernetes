source ./pubfunc.sh

#if ! $(ip_exists "10.45.80.190")
#then
#    exit
#fi

STAMP_CACHE=.DOCKER_EVENT_STAMP.CACHE
NOW_STAMP=$(date "+%FT%T.%N%:z")
LAST_STAMP=$(cat ${STAMP_CACHE})

if [ ${LAST_STAMP}"x" = "x" ]
then
    LAST_STAMP=${NOW_STAMP}
fi

docker events --since ${LAST_STAMP} --until ${NOW_STAMP} --filter event=oom | while read LINE
do
    #2018-12-30T13:31:53.513799114+04:00 container oom 38b932edc0df... (image=10.10.171.81:52800/zcm9/influxdb:latest, name=nms-influxdb)
    #2018-12-29T18:00:02.911573927+04:00 container oom 5e86984d0849... (build-date=20161214, image=10.10.171.81:52800/dbeppr/med_backend_product:C_20181228213409, name=med-backend-product, vendor=CentOS, zcm.cicd.branch-name=null ... ztesoft.maintainer=OCS TEAM)
    #2019-01-03T22:22:52.361887752+04:00 container kill 7749d53ccd74... (annotation.kubernetes.io/config.seen=2019-01-03T22:22:20.899659271+04:00, annotation.kubernetes.io/config.source=api, annotation.kubernetes.io/created-by={"kind":"SerializedReference","apiVersion":"v1","reference":{"kind":"ReplicaSet","namespace":"dbeppr","name":"charging-webser-product-594756f4b6",...}}
    if [ $(echo ${LINE} | grep -c "annotation.kubernetes.io") -gt 0 ]
    then 
        DOCKER_NAME=${LINE##*\"name\":\"}
        DOCKER_NAME=${DOCKER_NAME%%\"*}
    else
        DOCKER_NAME=${LINE##* name=}
        DOCKER_NAME=${DOCKER_NAME%%)*}
        DOCKER_NAME=${DOCKER_NAME%%,*}
    fi 
    send_alarm "Docker [${DOCKER_NAME}] Out of Memeory, container die"
done
