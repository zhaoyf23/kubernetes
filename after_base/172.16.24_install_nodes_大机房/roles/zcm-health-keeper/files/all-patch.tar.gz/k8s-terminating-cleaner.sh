source ./pubfunc.sh

found="NO"

for ip in ${K8S_MASTER_VIP//,/ }
do
  if ip_exists $ip
  then
    found="YES"
    break;
  fi
done

if [ ${found} = "NO" ]
then
    exit
fi

kubectl get pods -o wide --all-namespaces=true | grep "Terminating" |while read ALINE
do
    NAMESPACE=$(echo $ALINE|awk '{print $1}')
    POD_NAME=$(echo $ALINE|awk '{print $2}')
    POD_INFO=$(kubectl describe pod ${POD_NAME} -n ${NAMESPACE})
    TIME_STR=$(echo "${POD_INFO}" | grep "Status" | grep "Terminating" | grep "expires")
    TIME_STR=${TIME_STR##*expires }
    TIME_STR=${TIME_STR%)*}
    DATE_NOW=$(date +%s)
    DATE_EXP=$(date -d "${TIME_STR}" +%s)
    WAIT_SECS=$(expr ${DATE_NOW} - ${DATE_EXP})
    if [ ${WAIT_SECS} -gt 300 ]
    then
        send_alarm "pod:[${POD_NAME}] terminating too long time, force delete it"
        kubectl delete pods ${POD_NAME} -n ${NAMESPACE} --grace-period=0 --force
        print_info "${POD_INFO}"
    fi
done
