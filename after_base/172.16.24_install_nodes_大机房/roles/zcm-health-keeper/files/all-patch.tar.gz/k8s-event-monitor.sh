source ./pubfunc.sh

found="NO"

for ip in ${K8S_MASTER_VIP//,/ }
do
  if ip_exists $ip
  then
    found="YES"
    break;
  fi
done

if [ ${found} = "NO" ]
then
    exit
fi

CACHE_FILE=".K8S_EVENT.CACHE"
if [ ! -e ${CACHE_FILE} ]
then
    touch ${CACHE_FILE}
fi

kubectl get events -o=custom-columns=NAME:.metadata.name,TYPE:.type,REASON:.reason,MESSAGE:.message --all-namespaces=true --no-headers=true| grep -v "Normal" | tr -s [:space:] | while read LINE
do
    if ! grep "${LINE}" ${CACHE_FILE}
    then
        echo "${LINE}" >> ${CACHE_FILE}
        send_alarm "$LINE"
    fi
done

if [ $(du -k ${CACHE_FILE}|awk '{print $1}') -gt 200 ]
then
    tail -200 ${CACHE_FILE} > ${CACHE_FILE}.swap
    mv ${CACHE_FILE}.swap ${CACHE_FILE}
fi

