source ./pubfunc.sh

found="NO"

for ip in ${K8S_MASTER_VIP//,/ }
do
  if ip_exists $ip
  then
    found="YES"
    break;
  fi
done

if [ ${found} = "NO" ]
then
    exit
fi

CACHE_FILE=".K8S_FAIL_APP.CACHE"
if [ ! -e ${CACHE_FILE} ]
then
    touch ${CACHE_FILE}
fi

CACHE_FILE_T1=".K8S_FAIL_APP_T1.CACHE"
if [ ! -e ${CACHE_FILE_T1} ]
then
    touch ${CACHE_FILE_T1}
fi

CACHE_FILE_T2=".K8S_FAIL_APP_T2.CACHE"
if [ ! -e ${CACHE_FILE_T2} ]
then
    touch ${CACHE_FILE_T2}
fi

> ${CACHE_FILE_T2}
kubectl get deployments --all-namespaces=true --no-headers=true | while read LINE
do
    NAMESPACE=$(echo ${LINE} | awk '{print $1}')
    APP_NAME=$(echo ${LINE} | awk '{print $2}')
    DESIRED=$(echo ${LINE} | awk '{print $3}')
    AVAILABLE=$(echo ${LINE} | awk '{print $6}')
    if [ ${DESIRED} = ${AVAILABLE} ] 
    then
        continue
    fi
    APP_KEY=${NAMESPACE}${APP_NAME}$(date +"%Y%m%d")
    echo "${APP_KEY}" >> ${CACHE_FILE_T2}
    if grep ${APP_KEY} ${CACHE_FILE_T1}
    then
        if ! grep ${APP_KEY} ${CACHE_FILE}
        then
            echo "${APP_KEY}" >> ${CACHE_FILE}
            ALARM_INFO="NAMESPACE:[ ${NAMESPACE} ] APP:[ ${APP_NAME} ] not fully ready(${AVAILABLE}/${DESIRED}), please check applicaiton status !"
            send_alarm "$ALARM_INFO"
        fi 
    fi
done
mv ${CACHE_FILE_T2} ${CACHE_FILE_T1}

if [ $(du -k ${CACHE_FILE}|awk '{print $1}') -gt 200 ]
then
    tail -200 ${CACHE_FILE} > ${CACHE_FILE}.swap
    mv ${CACHE_FILE}.swap ${CACHE_FILE}
fi
