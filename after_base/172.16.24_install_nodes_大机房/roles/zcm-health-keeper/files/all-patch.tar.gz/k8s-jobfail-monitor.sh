source ./pubfunc.sh

found="NO"

for ip in ${K8S_MASTER_VIP//,/ }
do
  if ip_exists $ip
  then
    found="YES"
    break;
  fi
done

if [ ${found} = "NO" ]
then
    exit
fi

CACHE_FILE=".K8S_JOB_STATUS.CACHE"
if [ ! -e ${CACHE_FILE} ]
then
    touch ${CACHE_FILE}
fi


kubectl get cronjob --all-namespaces --no-headers=true | while read CRONJOB_INFO
do 
    NAMESPACE=$(echo "$CRONJOB_INFO" | awk '{print $1}')
    CRONJOB_NAME=$(echo "$CRONJOB_INFO" | awk '{print $2}')
    kubectl get job -n ${NAMESPACE} | grep ${CRONJOB_NAME}"-" | while read JOB_INFO
    do  
        echo ${JOB_INFO}
        JOB_NAME=$(echo "$JOB_INFO" | awk '{print $1}')
        if ! grep "${JOB_NAME}" ${CACHE_FILE}
        then
            JOB_DETAIL=$(kubectl describe job $JOB_NAME -n $NAMESPACE)
            RUNNING_NUM=$(echo "${JOB_DETAIL}" | grep "Pods Statuses:" | awk '{print $3}')
            if [ ${RUNNING_NUM} -eq 0 ]
            then
                echo "${JOB_NAME}" >> ${CACHE_FILE}
                FAIL_NUM=$(echo "${JOB_DETAIL}" | grep "Pods Statuses:" | awk '{print $9}')
                if [ ${FAIL_NUM} -eq 0 ]
                then
                    ALARM_INFO="namespace:${NAMESPACE}, Job:$JOB_NAME execute failed !"
                    send_alarm "$ALARM_INFO"
                fi
            fi
        fi
    done
done

if [ $(du -k ${CACHE_FILE}|awk '{print $1}') -gt 200 ]
then
    tail -200 ${CACHE_FILE} > ${CACHE_FILE}.swap
    mv ${CACHE_FILE}.swap ${CACHE_FILE}
fi
