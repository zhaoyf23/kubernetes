source ./pubfunc.sh

found="NO"

for ip in ${K8S_MASTER_VIP//,/ }
do
  if ip_exists $ip
  then
    found="YES"
    break;
  fi
done

if [ ${found} = "NO" ]
then
    exit
fi

CACHE_FILE=".K8S_NODE_NOTREADY.CACHE"
if [ ! -e ${CACHE_FILE} ]
then
    touch ${CACHE_FILE}
fi

kubectl get nodes --no-headers=true | grep "NotReady" | while read LINE
do
    NODE=$(echo ${LINE} | awk '{print $1}')
    NODE_DAY=${NODE}$(date +"%Y%m%d")
    if ! grep "${NODE_DAY}" ${CACHE_FILE}
    then
        echo "${NODE_DAY}" >> ${CACHE_FILE}
        ALARM_INFO="Node:[ ${NODE} ] offline(not ready), please check server status and kubelet service !"
        send_alarm "$ALARM_INFO"
    fi
done

if [ $(du -k ${CACHE_FILE}|awk '{print $1}') -gt 200 ]
then
    tail -200 ${CACHE_FILE} > ${CACHE_FILE}.swap
    mv ${CACHE_FILE}.swap ${CACHE_FILE}
fi

