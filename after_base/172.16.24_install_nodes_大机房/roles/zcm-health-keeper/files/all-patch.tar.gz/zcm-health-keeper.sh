#!/bin/bash
# http://gitlab.iwhalecloud.com/cloud/platform/issues/694

. /zcm/supervisor/zcm-env.profile
source /etc/profile

WORK_HOME=/zcm/health-keeper

source ${WORK_HOME}/pubfunc.sh

run_plugins()
{
    cd ${WORK_HOME}
    ls *.sh 2>/dev/null | grep -v -E "zcm-health-keeper.sh|pubfunc.sh" | while read PLUGIN
    do
        print_info "Begin "${PLUGIN}
        cd ${WORK_HOME}
        bash ${PLUGIN}
        print_info "End "${PLUGIN}
    done
}

while [ 1 = 1 ]
do
   run_plugins
   sleep 60
done
