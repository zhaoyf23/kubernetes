source ./pubfunc.sh

if [ ${DEBUG} ]
then
    export
fi