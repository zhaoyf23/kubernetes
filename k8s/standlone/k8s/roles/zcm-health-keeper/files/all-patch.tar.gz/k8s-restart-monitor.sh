source ./pubfunc.sh

found="NO"

for ip in ${K8S_MASTER_VIP//,/ }
do
  if ip_exists $ip
  then
    found="YES"
    break;
  fi
done

if [ ${found} = "NO" ]
then
    exit
fi

CACHE_FILE=".K8S_POD_RESTART.CACHE"
if [ ! -e ${CACHE_FILE} ]
then
    touch ${CACHE_FILE}
fi

kubectl get pods --all-namespaces=true --no-headers=true | while read LINE
do
    NAMESPACE=$(echo "${LINE}" | awk '{print $1}')
    POD_NAME=$(echo "${LINE}" | awk '{print $2}')
    RESTARTS=$(echo "${LINE}" | awk '{print $5}')
    if [ $RESTARTS -gt 10 ]
    then
        POD_DAY=${POD_NAME}$(date +"%Y%m%d")
        if ! grep "${POD_DAY}" ${CACHE_FILE}
        then
            echo "${POD_DAY}" >> ${CACHE_FILE}
            ALARM_INFO="NAMESPACE:[ ${NAMESPACE} ] POD:[ ${POD_NAME} ] restart too many times: [${RESTARTS}], please check appliction configuration !"
            send_alarm "$ALARM_INFO"
        fi
    fi
done

if [ $(du -k ${CACHE_FILE}|awk '{print $1}') -gt 200 ]
then
    tail -200 ${CACHE_FILE} > ${CACHE_FILE}.swap
    mv ${CACHE_FILE}.swap ${CACHE_FILE}
fi
