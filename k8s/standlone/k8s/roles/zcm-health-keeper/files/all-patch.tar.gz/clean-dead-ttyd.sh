source ./pubfunc.sh

#if ! $(ip_exists "10.45.80.190")
#then
#    exit
#fi

for DEAD_TTYD in $(ps -eo pid,etime,command |grep -v grep| grep "ttyd -p 0"|awk '{ if (length($2)>5) {print $1} }')
do
    print_error "Dead ttyd found"
    print_error "$(ps -o pid,tid,class,rtprio,ni,pri,psr,pcpu,stat,wchan:14,comm -p ${DEAD_TTYD})"
    kill ${DEAD_TTYD}
done
