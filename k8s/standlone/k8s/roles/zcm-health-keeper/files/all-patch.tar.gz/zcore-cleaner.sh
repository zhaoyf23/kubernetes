source ./pubfunc.sh

#if ! $(ip_exists "10.45.80.190")
#then
#    exit
#fi

if [ ! -d /tmp/zcore ]
then
    print_info "skip"
    exit
fi

find /tmp/zcore -mtime +7 -type f
find /tmp/zcore -mtime +7 -type f -exec rm {} \;

clean_bigfile()
{
    FS_PCT=$(df /tmp/zcore 2>/dev/null |tail -1|awk '{print int($5)}')
    if [ ${FS_PCT} -gt $1 ]
    then
          for BIG_FILE in $(find /tmp/zcore -type f -size +${2}M)
          do
          print_error "truncate "${BIG_FILE}
           > ${BIG_FILE}
          done
    fi
}

FS_PCT=$(df /tmp/zcore 2>/dev/null |tail -1|awk '{print int($5)}')
if [ ${FS_PCT} -gt 90 ]
then
    print_error "filesystem nearly full, try protection"
    clean_bigfile 90 5120
    clean_bigfile 75 500
    clean_bigfile 75 50
    clean_bigfile 75 10
fi 
