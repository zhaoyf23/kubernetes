DEBUG=${ZCM_HEALTH_KEEPER_DEBUG}

print_console()
{
    printf "[%s][%s]->%s\n" "$(date +'%Y-%m-%d %H:%M:%S')" "$1" "$2"
}

print_debug()
{
    if [ ${DEBUG} ]
    then
        print_console "DEBUG" "$1"
    fi
}

print_info()
{
    print_console "INFO" "$1"
}

print_error()
{
    print_console "ERROR" "$1"
}

send_alarm()
{
    ALARM_MSG=$1
    ALARM_DETAIL="alarm send from node:[$(uname -n)], module:[${0%.*}]"
    
    curl -X POST "http://${NMS_MASTER_VIP}/portal/zcm-monitor/alarm" -H 'Content-Type: application/json' -H 'Accept: application/json' -d "{
    \"alarmCode\": \"ZCM_SYSTEM_ALARM\",
    \"alarmDetail\": \"${ALARM_DETAIL:0:500}\",
    \"alarmMessage\": \"${ALARM_MSG}\"
   }"

   print_error "${ALARM_MSG}"
   print_error "${ALARM_DETAIL}"
}

ip_exists()
{
   if [ $(ip addr show up | grep "$1" | wc -l) -gt 0 ]
   then
       return 0
   else
       return 1
   fi
}
