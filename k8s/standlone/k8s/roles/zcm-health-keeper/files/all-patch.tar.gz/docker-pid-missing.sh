source ./pubfunc.sh

#if ! $(ip_exists "10.45.80.190")
#then
#    exit
#fi

docker ps --filter "status=running" --format "{{.ID}}"|while read DOCKER_ID
do
    PID=$(docker inspect -f {{.State.Pid}} ${DOCKER_ID})
    if ! $(kill -0 $PID)
    then
        PS_INFO=$(ps p $PID | grep -v "COMMAND")
        if [ ${PS_INFO}"x" = "x" ]
        then
            DMESG=$(docker inspect ${DOCKER_ID} )
            DMESG=$DMESG"\n"$(ps aux)
            DMESG=$DMESG"\n"$PS_INFO
            send_alarm "${DMESG}"
            docker rm -f ${DOCKER_ID}
        fi
    fi
done